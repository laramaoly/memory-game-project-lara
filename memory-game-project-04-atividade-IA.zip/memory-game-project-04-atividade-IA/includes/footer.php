    </main> <footer>
        <p>&copy; <?php echo date("Y"); ?> Jogo da Memória - Versão PHP</p>
    </footer>

</body>
</html>
