<?php
// Este módulo contém a lógica da página do jogo

// Inclui o tabuleiro
include 'includes/tabuleiro_jogo.php';

// Inclui o script JS específico desta página
// O script só é carregado quando estamos na página "jogar"
echo '<script src="script.js"></script>';
?>
