<div class="game-info">
    <h2>Tentativas: <span id="attempts">0</span></h2>
</div>

<div id="board" class="memory-game">
</div>

<form id="scoreForm" action="salvar_pontuacao.php" method="POST" style="display: none;">
    <input type="hidden" id="hiddenName" name="nome" value="">
    <input type="hidden" id="hiddenAttempts" name="tentativas" value="0">
</form>
