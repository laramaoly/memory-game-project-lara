<nav class="global-menu">
    <ul>
        <li><a href="index.php?page=jogar">Jogar</a></li>
        
        <li><a href="index.php?page=placar">Placar</a></li>
    </ul>
</nav>
