<?php
$server = "mysql";
$user = "root";
$pass = "root";
$db = "jogo_memoria";
?>
